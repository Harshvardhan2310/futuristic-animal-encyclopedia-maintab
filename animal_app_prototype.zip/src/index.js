
import React from 'react';
import ReactDOM from 'react-dom/client';
import MainTab from './MainTab';
import './MainTab.css';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<MainTab />);
